function [Ux1, Ux2, Ux3, Ux]= INTG02(x, X, y, Y, z, Z, F, FF, DH, NMAX, E, vvmu)
III = sqrt(-1);
MO1=0;% the low limit of the integration

ME2=DH/2;%the high limit of the integration, becuase the integration region is (0,infinity) in equation (A13),we use the value x2 represent infinity

m=(NMAX+1)/2;%%��
MPm=(ME2+MO1)/2;%midpoint 
MPl=(ME2-MO1)/2;%midpoint
for i=1:m
MZ=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z1=MZ-1;%0>Z1>-1
ZZ(floor(i))=MZ;
ZZZ(i)=MZ-Z1;
while (MZ-Z1) > 3d-14
p1=1;
p2=0;
for j=1:NMAX
p3=p2;
p2=p1;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p1=((2*j-1)*MZ*p2-(j-1)*p3)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(MZ*p1-p2)/(MZ^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z1=MZ;
MZ=Z1-p1/pp;
end
MP(i)=MPm-MPl*MZ;%x1<x<(x2+x1)/2
MP(NMAX+1-i)=MPm+MPl*MZ;%x2>x>(x2+x1)/2
w(i)=2*MPl/((1-MZ^2)*pp^2);%(x2-x1)/2
w(NMAX+1-i)=w(i);
end
for i=1:NMAX
u(i)=MP(i);
end
for i=1:NMAX
RR2=3.0e-05;
a = (3.*pi.*FF.*RR2./2.*(1-vvmu.^2)./E).^(1/3);
zz = z+III.*u(i);
R = sqrt((x-X).^2+(y-Y).^2+(zz-Z).^2);
FFF = 3.*F./a.^3.*u(i);
ux1(i) = -FFF.*(x-X).*(y-Y)./(R+zz-Z).^2.*w(i);
ux2(i) = FFF.*(x-X).*(y-Y)./(R+zz-Z).^2.*w(i);
ux3(i) = -FFF.*(x-X).*(y-Y).*(z-Z)./(R+zz-Z).^2./R.*w(i);
end
Ux1 = imag(sum(ux1));
Ux2 = imag(sum(ux2));
Ux3 = imag(sum(ux3));
Ux = (1+vvmu)./(4.*pi.*E).*Ux1+2*(1-vvmu).*(1+vvmu)./(4.*pi.*E).*Ux2+(1+vvmu)./(2.*pi.*E).*Ux3;
end