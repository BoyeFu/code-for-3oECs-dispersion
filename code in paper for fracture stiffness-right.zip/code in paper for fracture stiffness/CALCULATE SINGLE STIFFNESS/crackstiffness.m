%%
%The crack stiffness data
%The crack length is 100um, height is 1um, and the standard deviation height 0.001um
%Autocorrelation length = 1 um
%Quartz
STCRACK001 = [0.00194654	0.002524904	0.0097129	0.023632348	0.039384788	0.061323593	0.085052097	0.1107779];
STPRE001 = [0	0.298864741	0.640456532	1.619032668	3.826361745	6.568469671	9.666908213	13.93762938];
%Autocorrelation length = 10 um
STCRACK010 = [0.006649454	0.024009535	0.048241941	0.080398298	0.100339718	0.119570148	0.13183099	0.144246096];
STPRE010 = [0	0.41320598	1.582759274	3.935769798	6.929583433	10.6573809	13.61830548	16.86163904];
%Autocorrelation length = 20 um
STCRACK020 =[0.02024708	0.048424123	0.067460905	0.086305806	0.098503016	0.110998472	0.118798324	0.134210732];
STPRE020 = [0	0.797387213	2.329036606	4.444630464	6.45711128	8.720523106	10.40659621	12.19239437];
%Autocorrelation length = 50 um
STCRACK050 = [0.025542067	0.060483652	0.085036727	0.106304137	0.120387574	0.132243078	0.141728188	0.155380237];
STPRE050 = [0	1.012214581	2.942876251	5.630486073	8.124953186	10.91421501	12.92887952	15.07051191];
%Autocorrelation length 100 um
STCRACK100 = [0.025196418	0.057455017	0.078283414	0.097636374	0.111761283	0.125227575	0.13297916	0.143853479];
STPRE100 = [0	1.005983145	2.869487138	5.397357205	7.748816672	10.41647968	12.39357412	14.46656013];
%%
%Plot the figure
figure(1)
plot(STPRE001,STCRACK001)
hold on
plot(STPRE010,STCRACK010)
hold on
plot(STPRE020,STCRACK020)
hold on
plot(STPRE050,STCRACK050)
hold on
plot(STPRE100,STCRACK100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting
PREEX = (1:0.1:15);%The Pressure for simulation
%Autocorrelation length = 1 um
TOE001 = polyfit(STPRE001,STCRACK001,1);
STF001TO = polyval(TOE001,PREEX);
%Autocorrelation length = 10 um
TOE010 = polyfit(STPRE010,STCRACK010,1);
STF010TO = polyval(TOE010,PREEX);
%Autocorrelation length = 20 um
TOE020 = polyfit(STPRE020,STCRACK020,1);
STF020TO = polyval(TOE020,PREEX);
%Autocorrelation length = 50 um
TOE050 = polyfit(STPRE050,STCRACK050,1);
STF050TO = polyval(TOE050,PREEX);
%Autocorrelation length = 100 um
TOE100 = polyfit(STPRE100,STCRACK100,1);
STF100TO = polyval(TOE100,PREEX);
%%
%plot the Figure
figure(2)
plot(PREEX,STF001TO)
hold on
plot(PREEX,STF010TO)
hold on
plot(PREEX,STF020TO)
hold on
plot(PREEX,STF050TO)
hold on
plot(PREEX,STF100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%New sample Yanyan
STCRACKYY001 = [0.00079251	0.000931332	0.004120363	0.007793148	0.020579987	0.038499424	0.051049309	0.06419595];
STPREYY001 = [0	0.202737285	0.355327594	0.931704087	1.630869606	3.365054813	5.46356364	8.213693503];
%Autocorrelation length = 10 um
STCRACKYY010 = [0.005469845	0.015377379	0.02303006	0.031004413	0.041231686	0.055593398	0.062841233	0.072040536];
STPREYY010 = [0	0.356415558	1.151989885	2.333955441	3.515672137	5.096625839	6.552226966	8.187464377];
%Autocorrelation length = 20 um
STCRACKYY020 =[0.00846169	0.0200158	0.027861821	0.035602755	0.041007088	0.046395757	0.051646188	0.057789789];
STPREYY020 = [0	0.556028013	1.590818916	2.995307749	4.307608278	5.780010667	6.870309792	8.073653803];
%Autocorrelation length = 50 um
STCRACKYY050 = [0.011195278	0.023972153	0.032299883	0.039735595	0.044594887	0.050018095	0.053076109	0.056905667];
STPREYY050 = [0	0.739579318	1.984545642	3.621491968	5.092293829	6.698810821	7.876329835	9.102209186];
%Autocorrelation length 100 um
STCRACKYY100 = [0.012098863	0.028967392	0.03912266	0.04728462	0.052366583	0.058368551	0.063901518	0.069749457];
STPREYY100 = [0	0.641507466	1.870219591	3.501215296	4.951223978	6.520227688	7.669820925	8.920581553];
figure(3)
plot(STPREYY001,STCRACKYY001)
hold on
plot(STPREYY010,STCRACKYY010)
hold on
plot(STPREYY020,STCRACKYY020)
hold on
plot(STPREYY050,STCRACKYY050)
hold on
plot(STPREYY100,STCRACKYY100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting Yanyan
PREEXYY = (1:0.1:8);%The Pressure for simulation
%Autocorrelation length = 1 um
TOEYY001 = polyfit(STPREYY001,STCRACKYY001,1);
STFYY001TO = polyval(TOEYY001,PREEXYY);
%Autocorrelation length = 10 um
TOEYY010 = polyfit(STPREYY010,STCRACKYY010,1);
STFYY010TO = polyval(TOEYY010,PREEXYY);
%Autocorrelation length = 20 um
TOEYY020 = polyfit(STPREYY020,STCRACKYY020,1);
STFYY020TO = polyval(TOEYY020,PREEXYY);
%Autocorrelation length = 50 um
TOEYY050 = polyfit(STPREYY050,STCRACKYY050,1);
STFYY050TO = polyval(TOEYY050,PREEXYY);
%Autocorrelation length = 100 um
TOEYY100 = polyfit(STPREYY100,STCRACKYY100,1);
STFYY100TO = polyval(TOEYY100,PREEXYY);
%%
%plot the Figure
figure(4)
plot(PREEXYY,STFYY001TO)
hold on
plot(PREEXYY,STFYY010TO)
hold on
plot(PREEXYY,STFYY020TO)
hold on
plot(PREEXYY,STFYY050TO)
hold on
plot(PREEXYY,STFYY100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')