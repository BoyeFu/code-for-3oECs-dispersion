%This function is used to calculate the average value
function [apt3x, apt3y] = CORRECTNS(apt,h)
A = apt;
[Nx,Ny]=size(A);
Avarage4 = zeros(Nx,Ny);%The space to store the avergae value for 4 value
for I = 1:Nx-1;
for   J = 1:Ny-1;
    Avarage4(I,J)=1/4*(A(I,J)+A(I,J+1)+A(I+1,J)+A(I+1,J+1));
end
end
%To obtain the value in the Ny line
for I = 1:Nx-1;
    Avarage4(I,Ny) = 1/2*(A(I,Ny)+A(I+1,Ny));
end
%To obtain the value in the Nx row
for J = 1:Ny-1
    Avarage4(Nx,J) = 1/2*(A(Nx,J)+A(Nx,J+1));
end
%To obtain the value in the value in Nx line and Ny row
Avarage4(Nx,Ny) = A(Nx,Ny);
Avarage2 = zeros(Nx,Ny);%To store the average value for 2 point value
%To obtain the value Nx line and Ny-1 row
for I = 1:Nx;
    for J = 1:Ny-1;
        Avarage2(I,J) = 1/2*(A(I,J)+A(I,J+1));
    end
end
%To obtain the value in the Ny row
Avarage2(:,Ny) = A(:,Ny);
%There should be 2 matrix of nz nzx nzy
lx = zeros(Nx,Ny);%to store the difference of the apeture in x direction
lx(1:Nx,1:Ny-1) = Avarage4(1:Nx,1:Ny-1)-Avarage4(1:Nx,2:Ny);
Lx = sqrt(lx.^2+h.^2);%The hypotenuse of the Lx
nzx = h./Lx;%The nz in x direction
ly = zeros(Nx,Ny);%to store the difference of the apeture in y direction
ly(1:Nx-1,1:Ny) = Avarage4(1:Nx-1,1:Ny)-Avarage4(2:Nx,1:Ny);
Ly = sqrt(ly.^2+h.^2);
nzy = h./Ly;%The nz in y direction
betafpx = 2.*nzx.^3;
betafpy = 2.*nzy.^3;
kappafpx = 2.*nzx;
kappafpy = 2.*nzy;
TANCITAfpx = kappafpx.*abs(Avarage2-Avarage4)./h;
TANCITAfpy = kappafpy.*abs(Avarage2-Avarage4)./h;
CITAfpx = atan(TANCITAfpx);
CITAfpy = atan(TANCITAfpy);
FACTORx = zeros(Nx,Ny);
FACTORy = zeros(Nx,Ny);
for I = 1:Nx
    for J = 1:Ny;
        if TANCITAfpx(I,J) == 0;
            FACTORx(I,J) = 1;
        else
            FACTORx(I,J) = 3*(TANCITAfpx(I,J)-CITAfpx(I,J))./TANCITAfpx(I,J)^3;
        end
    end
end
%%
for I = 1:Nx
    for J = 1:Ny;
        if TANCITAfpy(I,J) == 0;
            FACTORy(I,J) = 1;
        else
            FACTORy(I,J) = 3*(TANCITAfpy(I,J)-CITAfpy(I,J))./TANCITAfpy(I,J)^3;
        end
    end
end
bfp3x = 2.*Avarage2.^2.*Avarage4.^2./(Avarage2+Avarage4).*FACTORx;
bfp3y = 2.*Avarage2.^2.*Avarage4.^2./(Avarage2+Avarage4).*FACTORy;
apt3x = betafpx.*bfp3x./2;
apt3y = betafpx.*bfp3y./2;
end