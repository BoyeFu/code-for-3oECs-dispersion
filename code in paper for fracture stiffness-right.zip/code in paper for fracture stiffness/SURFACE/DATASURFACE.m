%%
clear
S20009 = load('S2N-0.0009.txt');
S20012 = load('S2N-0.0012.txt');
S20015 = load('S2N-0.0015.txt');
S20018 = load('S2N-0.0018.txt');
S20009SD = std(S20009,0,'all');%SSD
S20012SD = std(S20012,0,'all');%SSD
S20015SD = std(S20015,0,'all');%SSD
S20018SD = std(S20018,0,'all');%SSD