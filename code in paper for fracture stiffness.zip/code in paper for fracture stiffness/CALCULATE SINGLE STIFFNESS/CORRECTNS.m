%This function is used to calculate the average value
function [apt3x, apt3y] = CORRECTNS(apt,dx, dy)
A = apt;
[Ny,Nx]=size(A);
Avarage4 = zeros(Ny,Nx);%The space to store the avergae value for 4 value
for I = 1:Ny-1;
for   J = 1:Nx-1;
    Avarage4(I,J)=1/4*(A(I,J)+A(I,J+1)+A(I+1,J)+A(I+1,J+1));
end
end
%To obtain the value in the Ny line
for I = 1:Ny-1;
    Avarage4(I,Nx) = 1/2*(A(I,Nx)+A(I+1,Nx));
end
%To obtain the value in the Nx row
for J = 1:Nx-1
    Avarage4(Ny,J) = 1/2*(A(Ny,J)+A(Ny,J+1));
end
%To obtain the value in the value in Nx line and Ny row
Avarage4(Ny,Nx) = A(Ny,Nx);
Avarage2 = zeros(Ny,Nx);%To store the average value for 2 point value
%To obtain the value Nx line and Ny-1 row
for I = 1:Ny;
    for J = 1:Nx-1;
        Avarage2(I,J) = 1/2*(A(I,J)+A(I,J+1));
    end
end
%To obtain the value in the Ny row
Avarage2(:,Nx) = A(:,Nx);
%There should be 2 matrix of nz nzx nzy
lx = zeros(Ny,Nx);%to store the difference of the apeture in x direction
lx(1:Ny,1:Nx-1) = Avarage4(1:Ny,1:Nx-1)-Avarage4(1:Ny,2:Nx);
Lx = sqrt(lx.^2+dx.^2);%The hypotenuse of the Lx
nzx = dx./Lx;%The nz in x direction
ly = zeros(Ny,Nx);%to store the difference of the apeture in y direction
ly(1:Ny-1,1:Nx) = Avarage4(1:Ny-1,1:Nx)-Avarage4(2:Ny,1:Nx);
Ly = sqrt(ly.^2+dy.^2);
nzy = dy./Ly;%The nz in y direction
betafpx = 2.*nzx.^3;
betafpy = 2.*nzy.^3;
kappafpx = 2.*nzx;
kappafpy = 2.*nzy;
TANCITAfpx = kappafpx.*abs(Avarage2-Avarage4)./dx;
TANCITAfpy = kappafpy.*abs(Avarage2-Avarage4)./dy;
CITAfpx = atan(TANCITAfpx);
CITAfpy = atan(TANCITAfpy);
FACTORx = zeros(Ny,Nx);
FACTORy = zeros(Ny,Nx);
for I = 1:Ny
    for J = 1:Nx;
        if TANCITAfpx(I,J) == 0;
            FACTORx(I,J) = 1;
        else
            FACTORx(I,J) = 3*(TANCITAfpx(I,J)-CITAfpx(I,J))./(TANCITAfpx(I,J)^3);
        end
    end
end
%%
for I = 1:Ny
    for J = 1:Nx;
        if TANCITAfpy(I,J) == 0;
            FACTORy(I,J) = 1;
        else
            FACTORy(I,J) = 3*(TANCITAfpy(I,J)-CITAfpy(I,J))./(TANCITAfpy(I,J)^3);
        end
    end
end
bfp3x = zeros(Ny,Nx);
bfp3y = zeros(Ny,Nx);
for I = 1:Ny;
    for J = 1:Nx;
        if (Avarage2(I,J)+Avarage4(I,J)) == 0;
            bfp3x(I,J) = 0;
        else
bfp3x(I,J) = 2.*Avarage2(I,J).^2.*Avarage4(I,J).^2./(Avarage2(I,J)+Avarage4(I,J)).*FACTORx(I,J);
        end
    end
end
%%
for I = 1:Ny;
    for J = 1:Nx;
        if (Avarage2(I,J)+Avarage4(I,J)) == 0;
            bfp3y(I,J) = 0;
        else
bfp3y(I,J) = 2.*Avarage2(I,J).^2.*Avarage4(I,J).^2./(Avarage2(I,J)+Avarage4(I,J)).*FACTORy(I,J);
        end
    end
end
apt3x = betafpx.*bfp3x./2;
apt3y = betafpy.*bfp3y./2;
apt3x(isnan(apt3x)) = 0;
apt3x(apt3x==inf) = 0;
apt3y(isnan(apt3y)) = 0;
apt3y(apt3y==inf) = 0;
%%
% for I = 1:Ny
%     if apt3x(I,128) == 0;
%     apt3x(I,128) = 1e-10;
%     end
%     if apt3x(I,127) == 0;
%     apt3x(I,127) = 1e-10;
%     end
%     if apt3y(I,128) == 0;
%     apt3y(I,128) = 1e-10;
%     end
%     if apt3y(I,127) == 0;
%     apt3y(I,127) = 1e-10;
%     end
% end
end